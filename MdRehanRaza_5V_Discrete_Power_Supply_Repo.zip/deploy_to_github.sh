#!/usr/bin/env bash
set -e
GITHUB_USER="MdRehanRaza"
REPO_NAME="5V-Discrete-Power-Supply"

git init
git add .
git commit -m "Initial commit - Discrete 5V/100mA Power Supply (No ICs)"
git branch -M main
git remote add origin https://github.com/$GITHUB_USER/$REPO_NAME.git
git push -u origin main
echo "Pushed to https://github.com/$GITHUB_USER/$REPO_NAME"
