# Discrete 5V DC Power Supply (100mA, No IC)
**Author:** Md Rehan Raza  

## Project Overview
This project demonstrates the design of a regulated **5V DC, 100mA power supply** using only **discrete components** (no ICs).  
It uses a step-down transformer, bridge rectifier, capacitor filter, Zener diode, and transistor series regulator.

## Features
- Input: 230V AC (step-down to ~9V AC)
- Output: Regulated 5V DC @ 100mA
- Components: Transformer, Diodes, Capacitors, Resistors, Zener Diode, BD139 Transistor
- No integrated circuits used

## Real-World Application
- Embedded systems requiring low-power 5V supply
- Small sensors, logic circuits, and microcontroller projects

## Documentation
- [One Page Summary PDF](Discrete_5V_100mA_NoIC_Summary.pdf)
- [Schematic Diagram](schematic.png)

## Author's Note
This project was implemented and documented by **Md Rehan Raza** for academic and professional showcase.

---

## Repository Structure
```
/
├── hardware/
│   └── BOM.csv
├── schematics/
│   ├── schematic.png
│   └── schematic.svg
├── spice/
│   └── regulator_section.cir
├── docs/
│   └── Discrete_5V_100mA_NoIC_Summary.pdf
├── images/
│   └── (add build photos here)
├── LICENSE
└── README.md
```

## Quick Start (Local)
1. Open `docs/Discrete_5V_100mA_NoIC_Summary.pdf` for a one-page overview.
2. Review `schematics/schematic.png` and `hardware/BOM.csv`.
3. (Optional) Simulate `spice/regulator_section.cir` in LTspice/NGspice.

## Upload to GitHub (GUI)
1. Create a new public repo named **5V-Discrete-Power-Supply** on GitHub.
2. Click **Add file → Upload files**.
3. Drag & drop all files/folders from this package into the repo root.
4. **Commit changes** → Done.

## Upload to GitHub (CLI)
```bash
GITHUB_USER="MdRehanRaza"
REPO_NAME="5V-Discrete-Power-Supply"

git init
git add .
git commit -m "Initial commit - Discrete 5V/100mA Power Supply (No ICs)"
git branch -M main
git remote add origin https://github.com/$GITHUB_USER/$REPO_NAME.git
git push -u origin main
```

---
© 2025 Md Rehan Raza — MIT License