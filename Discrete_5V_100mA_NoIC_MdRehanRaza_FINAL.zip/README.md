# Discrete 5V DC Power Supply (100mA, No IC)
**Author:** Md Rehan Raza  

## Project Overview
This project demonstrates the design of a regulated **5V DC, 100mA power supply** using only **discrete components** (no ICs).  
It uses a step-down transformer, bridge rectifier, capacitor filter, Zener diode, and transistor series regulator.

## Features
- Input: 230V AC (step-down to ~9V AC)
- Output: Regulated 5V DC @ 100mA
- Components: Transformer, Diodes, Capacitors, Resistors, Zener Diode, BD139 Transistor
- No integrated circuits used

## Real-World Application
- Embedded systems requiring low-power 5V supply
- Small sensors, logic circuits, and microcontroller projects

## Documentation
- [One Page Summary PDF](Discrete_5V_100mA_NoIC_Summary.pdf)
- [Schematic Diagram](schematic.png)

## Author's Note
This project was implemented and documented by **Md Rehan Raza** for academic and professional showcase.

---
